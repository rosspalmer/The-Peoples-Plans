

from setuptools import setup, find_packages

config = {
      'name': 'pplans',
      'description': 'The Peoples Plans python package',
      'author': 'ross palmer',
      'url': 'https://github.com/rosspalmer/The-Peoples-Plans',
      'license': 'TODO',
      'version': '0.0.0',
      'install_requires': [],
      'packages': find_packages(),
      'scripts': []
}

setup(**config)