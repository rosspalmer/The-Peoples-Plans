

def handler(event, context):

    print("HELLOOO MR")
    print(event)
